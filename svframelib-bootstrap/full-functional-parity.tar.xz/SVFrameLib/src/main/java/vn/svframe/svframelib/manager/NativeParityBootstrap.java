package vn.svframe.svframelib.manager;

import vn.svframe.svframelib.script.targeter.entity.*;
import vn.svframe.svframelib.script.targeter.location.*;

/** Registers the exact MythicLib 1.7.1 native targeter IDs on Fabric. */
public final class NativeParityBootstrap {
    private NativeParityBootstrap() {}

    public static void registerTargeters(SkillManager skills) {
        skills.registerEntityTargeter("caster", cfg -> new CasterTargeter());
        skills.registerEntityTargeter("cone", ConeTargeter::new);
        skills.registerEntityTargeter("nearby_entities", NearbyEntitiesTargeter::new);
        skills.registerEntityTargeter("nearest_entity", NearestEntityTargeter::new);
        skills.registerEntityTargeter("target", cfg -> new TargetTargeter());
        skills.registerEntityTargeter("variable", VariableEntityTargeter::new);
        skills.registerEntityTargeter("looking_at", vn.svframe.svframelib.script.targeter.entity.LookingAtTargeter::new);

        skills.registerLocationTargeter("caster", CasterLocationTargeter::new);
        skills.registerLocationTargeter("circle", CircleLocationTargeter::new);
        skills.registerLocationTargeter("custom", CustomLocationTargeter::new);
        skills.registerLocationTargeter("looking_at", vn.svframe.svframelib.script.targeter.location.LookingAtTargeter::new);
        skills.registerLocationTargeter("source_location", cfg -> new SourceLocationTargeter());
        skills.registerLocationTargeter("target", TargetEntityLocationTargeter::new);
        skills.registerLocationTargeter("target_location", cfg -> new TargetLocationTargeter());
        skills.registerLocationTargeter("variable", VariableLocationTargeter::new);
    }
}
