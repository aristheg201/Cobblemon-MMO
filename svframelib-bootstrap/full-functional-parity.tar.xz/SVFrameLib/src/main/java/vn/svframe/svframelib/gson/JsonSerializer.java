package vn.svframe.svframelib.gson;import java.lang.reflect.Type;@FunctionalInterface public interface JsonSerializer<T>{JsonElement serialize(T src,Type typeOfSrc,JsonSerializationContext context);}
