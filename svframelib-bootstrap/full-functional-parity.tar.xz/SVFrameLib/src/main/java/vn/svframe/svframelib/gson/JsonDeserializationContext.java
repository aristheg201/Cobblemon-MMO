package vn.svframe.svframelib.gson;import java.lang.reflect.Type;public interface JsonDeserializationContext{<T>T deserialize(JsonElement json,Type typeOfT)throws JsonParseException;}
