package vn.svframe.svframelib.gson;
import java.lang.reflect.Type;import java.util.Objects;
/** Relocated-compatible builder backed by Gson bundled with Minecraft. */
public class GsonBuilder{
 private final com.google.gson.GsonBuilder delegate=new com.google.gson.GsonBuilder();
 public GsonBuilder setPrettyPrinting(){delegate.setPrettyPrinting();return this;}public GsonBuilder disableHtmlEscaping(){delegate.disableHtmlEscaping();return this;}public GsonBuilder serializeNulls(){delegate.serializeNulls();return this;}
 public GsonBuilder registerTypeAdapter(Type type,Object adapter){Objects.requireNonNull(type);Objects.requireNonNull(adapter);Object bridge=adapter;
  if(adapter instanceof JsonSerializer<?> serializer && adapter instanceof JsonDeserializer<?> deserializer){bridge=new com.google.gson.TypeAdapter<Object>(){public void write(com.google.gson.stream.JsonWriter out,Object value)throws java.io.IOException{JsonElement e=((JsonSerializer<Object>)serializer).serialize(value,type,new Ser(delegate.create()));com.google.gson.internal.Streams.write(e==null?com.google.gson.JsonNull.INSTANCE:e.unwrap(),out);}public Object read(com.google.gson.stream.JsonReader in)throws java.io.IOException{com.google.gson.JsonElement raw=com.google.gson.internal.Streams.parse(in);return ((JsonDeserializer<Object>)deserializer).deserialize(JsonElement.wrap(raw),type,new Des(delegate.create()));}};}
  else if(adapter instanceof JsonSerializer<?> serializer){bridge=(com.google.gson.JsonSerializer<Object>)(src,t,ctx)->{JsonElement e=((JsonSerializer<Object>)serializer).serialize(src,t,new Ser(ctx));return e==null?com.google.gson.JsonNull.INSTANCE:e.unwrap();};}
  else if(adapter instanceof JsonDeserializer<?> deserializer){bridge=(com.google.gson.JsonDeserializer<Object>)(json,t,ctx)->((JsonDeserializer<Object>)deserializer).deserialize(JsonElement.wrap(json),t,new Des(ctx));}
  delegate.registerTypeAdapter(type,bridge);return this;}
 public Gson create(){return new Gson(delegate.create());}
 public Gson build(){return create();}
 private record Ser(com.google.gson.JsonSerializationContext delegate) implements JsonSerializationContext{public JsonElement serialize(Object src){return JsonElement.wrap(delegate.serialize(src));}public JsonElement serialize(Object src,Type type){return JsonElement.wrap(delegate.serialize(src,type));}}
 private record Des(com.google.gson.JsonDeserializationContext delegate) implements JsonDeserializationContext{public <T>T deserialize(JsonElement json,Type type){try{return delegate.deserialize(json.unwrap(),type);}catch(com.google.gson.JsonParseException e){throw new JsonParseException(e.getMessage(),e);}}}
}
