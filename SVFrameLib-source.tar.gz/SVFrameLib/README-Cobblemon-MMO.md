# SVFrameLib Fabric 1.21.1

Native Fabric port of MythicLib 1.7.1 for Minecraft 1.21.1 / Fabric Loader >= 0.18.4.

Development branch: `svframelib-fabric-1.21.1`.

This snapshot contains only SVFrameLib/MythicLib code and its shared runtime; MMOCore, MMOItems and MythicMobs are intentionally excluded from this branch.
